package Modelagem;

public class Numeros {
    private int[] array;

    public Numeros(int[] array) {
        this.array = array;
    }

    public int[] getArray() {
        return array;
    }

    public void setArray(int[] array) {
        this.array = array;
    }
}