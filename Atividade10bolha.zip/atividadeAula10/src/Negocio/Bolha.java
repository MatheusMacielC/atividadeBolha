package Negocio;

import java.util.Scanner;

public class Bolha {
    private static Scanner scanner = new Scanner(System.in);

    public static int[] inserirNumeros() {
        int[] arrayNumeros = new int[10];

        for (int i = 0; i < 10; i++) {
            System.out.print("Digite o " + (i + 1) + "º número: ");
            arrayNumeros[i] = scanner.nextInt();
        }

        return arrayNumeros;
    }

    public static void exibirNumerosOrdenados(int[] numeros) {
        System.out.println("Números ordenados:");
        for (int i = 0; i < 10; i++) {
            System.out.println((i + 1) + "º número: " + numeros[i]);
        }
    }

    public static int[] bubbleSort(int[] array) {
        int n = array.length;
        int temp = 0;

        for (int i = 0; i < n; i++) {
            for (int j = 1; j < (n - i); j++) {
                if (array[j - 1] > array[j]) {
                    // troca os elementos
                    temp = array[j - 1];
                    array[j - 1] = array[j];
                    array[j] = temp;
                }
            }
        }
        return array;
    }
}