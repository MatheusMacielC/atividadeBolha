package Visao;

import Negocio.Bolha;

public class Main {
    public static void main(String[] args) {
        int[] numeros = Bolha.inserirNumeros();
        int[] numerosOrdenados = Bolha.bubbleSort(numeros);
        Bolha.exibirNumerosOrdenados(numerosOrdenados);
    }
}